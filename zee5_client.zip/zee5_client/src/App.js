import { useEffect } from 'react';
import { Provider } from 'react-redux';
import { loadUser } from './redux/actions/authAction';
import store from './redux/store';
import { Routings } from './route/Routings';
import setAuthToken from './utils/setAuthToken';


if (localStorage.token) {
  setAuthToken(localStorage.token);
}

function App() {
  useEffect(() => {
    store.dispatch(loadUser(localStorage.getItem("id")));
  })

  return (
    <Provider store={store}>
      <div className="App">
        <Routings />
      </div>
    </Provider>
  );
}

export default App;
