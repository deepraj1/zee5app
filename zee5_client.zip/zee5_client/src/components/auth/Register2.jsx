import React, { useState } from "react";
import classNames from "classnames";
import { register } from "../../redux/actions/authAction";
import { Navigate } from "react-router-dom";
import { connect } from "react-redux";
import PropTypes from "prop-types";

const Register2 = ({ register, isAuthenticated, setAlert }) => {
	const [form, setForm] = useState({
		username: "",
		firstName: "",
		lastName: "",
		email: "",
		password: "",
		password2: "",
	});

	const [errors, setErrors] = useState({});

	const { username, firstName, lastName, email, password, password2 } = form;

	const onChange = (e) => {
		const n = e.target.name;
		const value = e.target.value;

		setForm({ ...form, [n]: value });
	};

	const onSubmit = (event) => {
		event.preventDefault();

		const errObj = {};
		if (form.password !== form.password2) {
			errObj.password2 = "Passwords do not match";
			setErrors(errObj);
			return;
		}

		register({ username, firstName, lastName, email, password });
	};

	if (isAuthenticated) {
		return <Navigate to='/dashboard' />;
	}

	return (
		<div>
			<section
				className='container'
				style={{
					maxWidth: "600px",
				}}
			>
				<h1 className='large text-primary'>Sign Up</h1>
				<p className='lead'>
					<i className='fas fa-user'></i> Create Your Account
				</p>
				<form className='form' onSubmit={onSubmit}>
					<div className='form-group'>
						<input
							type='text'
							placeholder='Username'
							name='username'
							required
							onChange={onChange}
							value={username}
							className={classNames("form-control form-control-lg", {
								"is-invalid": errors.name,
							})}
						/>
					</div>
					<div className='form-group'>
						<input
							type='text'
							placeholder='first Name'
							name='firstName'
							required
							onChange={onChange}
							value={firstName}
							className={classNames("form-control form-control-lg", {
								"is-invalid": errors.name,
							})}
						/>
					</div>
					<div className='form-group'>
						<input
							type='text'
							placeholder='Last Name'
							name='lastName'
							required
							onChange={onChange}
							value={lastName}
							className={classNames("form-control form-control-lg", {
								"is-invalid": errors.name,
							})}
						/>
					</div>
					<div className='form-group'>
						<input
							type='email'
							placeholder='Email Address'
							name='email'
							onChange={onChange}
							value={email}
							className={classNames("form-control form-control-lg", {
								"is-invalid": errors.email,
							})}
						/>
						<div className='invalid-feedback'>{errors.email}</div>
						<small className='form-text'>
							This site uses Gravatar so if you want a profile image, use a
							Gravatar email
						</small>
					</div>
					<div className='form-group'>
						<input
							type='password'
							placeholder='Password'
							name='password'
							minLength='6'
							value={password}
							onChange={onChange}
							className={classNames("form-control form-control-lg", {
								"is-invalid": errors.password,
							})}
						/>
						<div className='d-block invalid-feedback'>{errors.password}</div>
					</div>
					<div className='form-group'>
						<input
							type='password'
							placeholder='Confirm Password'
							name='password2'
							minLength='6'
							onChange={onChange}
							value={password2}
							className={classNames("form-control form-control-lg", {
								"is-invalid": errors.password2,
							})}
						/>
						<div className='d-block invalid-feedback'>{errors.password2}</div>
					</div>
					<input type='submit' className='btn btn-primary' value='Register' />
				</form>
				<p className='my-1'>
					Already have an account? <a href='login.html'>Sign In</a>
				</p>
			</section>
		</div>
	);
};

Register2.propTypes = {
	register: PropTypes.func.isRequired,
	isAuthenticated: PropTypes.bool,
	setAlert: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({
	isAuthenticated: state.authReducer.isAuthenticated,
});

export default connect(mapStateToProps, { register })(Register2);
