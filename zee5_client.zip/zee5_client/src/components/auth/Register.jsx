import axios from "axios";
import classNames from "classnames";
import React, { Component } from "react";

export default class Register extends Component {
	constructor(props) {
		super(props);

		this.state = {
			name: "",
			email: "",
			password: "",
			password2: "",
			errors: {},
		};
	}

	onChange = (e) => {
		const n = e.target.name;
		const value = e.target.value;
		this.setState({ [n]: value });
	};

	onSubmit = (event) => {
		event.preventDefault();
		console.log(this.state);

		const { name, email, password } = this.state;

		const errObj = {};

		if (this.state.password !== this.state.password2) {
			errObj.password2 = "Passwords do not match";
			this.setState({ errors: errObj });
			return;
		}

		axios
			.post("/api/users", { name, email, password })
			.then((response) => {
				console.log(response);
			})
			.catch((error) => {
				error.response.data.errors.forEach((err) => {
					if (err.param === "email") {
						errObj.email = err.msg;
					}
					if (err.param === "password") {
						errObj.password = err.msg;
					}
					if (err.param === "name") {
						errObj.name = err.msg;
					}
				});
				this.setState({ errors: errObj });
			});
	};

	render() {
		return (
			<div>
				<section className='container'>
					<h1 className='large text-primary'>Sign Up</h1>
					<p className='lead'>
						<i className='fas fa-user'></i> Create Your Account
					</p>
					<form className='form' onSubmit={this.onSubmit}>
						<div className='form-group'>
							<input
								type='text'
								placeholder='Name'
								name='name'
								required
								onChange={(e) => this.onChange(e)}
								value={this.state.name}
								className={classNames("form-control form-control-lg", {
									"is-invalid": this.state.errors.name,
								})}
							/>
						</div>
						<div className='form-group'>
							<input
								type='email'
								placeholder='Email Address'
								name='email'
								onChange={(e) => this.onChange(e)}
								className={classNames("form-control form-control-lg", {
									"is-invalid": this.state.errors.email,
								})}
							/>
							<div className='invalid-feedback'>{this.state.errors.email}</div>
							<small className='form-text'>
								This site uses Gravatar so if you want a profile image, use a
								Gravatar email
							</small>
						</div>
						<div className='form-group'>
							<input
								type='password'
								placeholder='Password'
								name='password'
								minLength='6'
								onChange={(e) => this.onChange(e)}
								className={classNames("form-control form-control-lg", {
									"is-invalid": this.state.errors.password,
								})}
							/>
							<div className='d-block invalid-feedback'>
								{this.state.errors.password}
							</div>
						</div>
						<div className='form-group'>
							<input
								type='password'
								placeholder='Confirm Password'
								name='password2'
								minLength='6'
								onChange={(e) => this.onChange(e)}
								className={classNames("form-control form-control-lg", {
									"is-invalid": this.state.errors.password2,
								})}
							/>
							<div className='d-block invalid-feedback'>
								{this.state.errors.password2}
							</div>
						</div>
						<input type='submit' className='btn btn-primary' value='Register' />
					</form>
					<p className='my-1'>
						Already have an account? <a href='login.html'>Sign In</a>
					</p>
				</section>
			</div>
		);
	}
}
