import React, { Component } from "react";
import axios from "axios";
import classNames from "classnames";

export default class Login extends Component {
	constructor(props) {
		super(props);

		this.state = {
			email: "",
			password: "",
			errors: {},
		};
	}

	onChange = (e) => {
		const n = e.target.name;
		const value = e.target.value;
		this.setState({ [n]: value });
	};

	onSubmit = (event) => {
		event.preventDefault();

		const { email, password } = this.state;

		const errObj = {};

		axios
			.post("/api/auth", { email, password })
			.then((response) => {
				console.log(response);
			})
			.catch((error) => {
				error.response.data.errors.forEach((err) => {
					if (err.param === "email") {
						errObj.email = err.msg;
					}
					if (err.param === "password") {
						errObj.password = err.msg;
					}
				});
				console.log(errObj);
				this.setState({ errors: errObj });
			});
	};

	render() {
		return (
			<div>
				<section className='container'>
					{/* <div className='alert alert-danger'>Invalid credentials</div> */}
					<h1 className='large text-primary'>Sign In</h1>
					<p className='lead'>
						<i className='fas fa-user'></i> Sign into Your Account
					</p>
					<form className='form' onSubmit={this.onSubmit}>
						<div className='form-group'>
							<input
								type='email'
								placeholder='Email Address'
								name='email'
								required
								value={this.state.email}
								onChange={this.onChange}
								className={classNames("form-control form-control-lg", {
									"is-invalid": this.state.errors.email,
								})}
							/>
							<div className='invalid-feedback'>{this.state.errors.email}</div>
						</div>
						<div className='form-group'>
							<input
								type='password'
								placeholder='Password'
								name='password'
								required
								value={this.state.password}
								onChange={this.onChange}
								className={classNames("form-control form-control-lg", {
									"is-invalid": this.state.errors.password,
								})}
							/>
							<div className='invalid-feedback'>
								{this.state.errors.password}
							</div>
						</div>
						<input type='submit' className='btn btn-primary' value='Login' />
					</form>
					<p className='my-1'>
						Don't have an account? <a href='register.html'>Sign Up</a>
					</p>
				</section>
			</div>
		);
	}
}
