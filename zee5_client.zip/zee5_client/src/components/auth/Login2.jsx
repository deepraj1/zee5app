import { useState } from "react";
import classNames from "classnames";
import { login } from "../../redux/actions/authAction";
import { Navigate } from "react-router-dom";
import { connect } from "react-redux";
import PropTypes from "prop-types";

const Login2 = ({ login, isAuthenticated }) => {
	const [form, setForm] = useState({
		username: "",
		password: "",
	});

	const [
		errors,
		// setErrors
	] = useState({});

	const { username, password } = form;

	const onChange = (e) => {
		const n = e.target.name;
		const value = e.target.value;

		setForm({ ...form, [n]: value });
	};

	const onSubmit = (event) => {
		event.preventDefault();
		login(username, password);
	};

	if (isAuthenticated) {
		return <Navigate to='/dashboard' />;
	}

	return (
		<div>
			<section
				className='container'
				style={{
					maxWidth: "600px",
				}}
			>
				{/* <div className='alert alert-danger'>Invalid credentials</div> */}
				<h1 className='large text-primary'>Sign In</h1>
				<p className='lead'>
					<i className='fas fa-user'></i> Sign into Your Account
				</p>
				<form className='form' onSubmit={onSubmit}>
					<div className='form-group'>
						<input
							type='username'
							placeholder='username'
							name='username'
							required
							value={username}
							onChange={onChange}
							className={classNames("form-control form-control-lg", {
								"is-invalid": errors.username,
							})}
						/>
						<div className='invalid-feedback'>{errors.username}</div>
					</div>
					<div className='form-group'>
						<input
							type='password'
							placeholder='Password'
							name='password'
							required
							value={password}
							onChange={onChange}
							className={classNames("form-control form-control-lg", {
								"is-invalid": errors.password,
							})}
						/>
						<div className='invalid-feedback'>{errors.password}</div>
					</div>
					<input type='submit' className='btn btn-primary' value='Login' />
				</form>
				<p className='my-1'>
					Don't have an account? <a href='register.html'>Sign Up</a>
				</p>
			</section>
		</div>
	);
};

Login2.propTypes = {
	login: PropTypes.func.isRequired,
	isAuthenticated: PropTypes.bool,
};

const mapStateToProps = (state) => ({
	isAuthenticated: state.authReducer.isAuthenticated,
});

export default connect(mapStateToProps, { login })(Login2);
