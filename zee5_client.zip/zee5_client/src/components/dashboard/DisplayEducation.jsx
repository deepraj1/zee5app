import React from "react";

const DisplayEducation = ({ education }) => {
	return (
		<>
			<h2 class='my-2'>Education Credentials</h2>
			<table class='table'>
				<thead>
					<tr>
						<th>School</th>
						<th class='hide-sm'>Degree</th>
						<th class='hide-sm'>Years</th>
						<th />
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>Northern Essex</td>
						<td class='hide-sm'>Associates</td>
						<td class='hide-sm'>02-03-2007 - 01-02-2009</td>
						<td>
							<button class='btn btn-danger'>Delete</button>
						</td>
					</tr>
				</tbody>
			</table>
		</>
	);
};

export default DisplayEducation;
