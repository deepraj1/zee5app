import PropTypes from "prop-types";
import React, { useEffect } from "react";
import { connect } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import DashboardAction from "./DashboardAction";
import DisplayEducation from "./DisplayEducation";
import DisplayExperience from "./DisplayExperience";
import axios from "axios";
import {
	getCurrentProfile,
	deleteAccount,
} from "../../redux/actions/profileAction";
import api from "../../utils/api";
import { loadUser } from "../../redux/actions/authAction";

// user details : user from auth combineReducers
// profile : profile detail from profilr reducer
// based on token we need to retrieve the currentProfileDetails  ==> experience and educational details

export const Dashboard = ({
	auth: { user },
	getCurrentProfile,
	loadUser, // this is action defined in profileAction
	profile: { profile }, // this came from profileReducer,
	deleteAccount,
}) => {
	const [movies, setMovies] = React.useState([]);

	useEffect(() => {
		// getCurrentProfile();

		// get the movies from the backend
		getMovies();
		loadUser(localStorage.getItem("id"));
	}, [loadUser]);

	const getMovies = async () => {
		const res = await api.get("/movie/");
		console.log(res.data);
		setMovies(res.data);
	};

	const navigate = useNavigate();
	// const existingProfile = (
	// 	<>
	// 		<DashboardAction />
	// 		{profile && <DisplayExperience experience={profile.experience} />}
	// 		{/* <DisplayExperience experience={profile.experience} /> */}

	// 		<DisplayEducation />
	// 		<div className='my-2'>
	// 			<button
	// 				className='btn btn-danger'
	// 				onClick={() => deleteAccount(navigate)}
	// 			>
	// 				<i className='fas fa-user-minus' /> Delete My Account
	// 			</button>
	// 		</div>
	// 	</>
	// );
	// const createProfile = (
	// 	<>
	// 		<p>You have not yet setup a profile, please add some info</p>
	// 		<Link to='/create-profile' className='btn btn-primary my-1'>
	// 			Create Profile
	// 		</Link>
	// 	</>
	// );
	return (
		<section className='container'>
			<h1 className='large primary'>Movies</h1>
			<p className='lead'>
				<i className='fas fa-user' /> welcome {user && user.firstName}
			</p>
			{/* {profile === null ? createProfile : existingProfile} */}
			<div
				class='container'
				style={{
					marginTop: "20px",
				}}
			>
				<div class='row'>
					{movies.map((movie) => (
						// <div class='col-md-4'>
						<div class='card text-center col-md-4 mt-3 col-sm-10 p-0'>
							<div class='card-header p-0'>
								<img
									src='https://i.pinimg.com/originals/fc/68/f8/fc68f86873c9c661e84ad442cf8fb6cf.gif'
									alt=''
									class='w-100'
								/>
							</div>
							<div class='card-body'>
								<h5 class='card-title'>{movie.movieName}</h5>
								<p class='card-text'>
									{/* director */}
									{movie.director}
								</p>
								<p
									class='card-text'
									style={{
										margin: "0px",
									}}
								>
									{/* time */}
									movie duration : {movie.movieLength}
								</p>
								<p class='card-text text-muted'>
									{/* languages */}
									{movie.languages.map((lang) => (
										<span>{lang}, </span>
									))}
								</p>
							</div>
							<div class='card-footer text-muted'>{movie.production}</div>
						</div>
						// </div>
					))}
				</div>
			</div>
		</section>
	);
};

Dashboard.propTypes = {
	auth: PropTypes.object.isRequired,
	getCurrentProfile: PropTypes.func.isRequired,
	loadUser: PropTypes.func.isRequired,
	deleteAccount: PropTypes.func.isRequired,
	profile: PropTypes.object.isRequired,
};

// here we used only reducer specification
const mapStateToProps = (state) => ({
	auth: state.authReducer,
	profile: state.profileReducer,
});

// here we used only action specifications
const mapDispatchToProps = { getCurrentProfile, loadUser, deleteAccount };

export default connect(mapStateToProps, mapDispatchToProps)(Dashboard);
