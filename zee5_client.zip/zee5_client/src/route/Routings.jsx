import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
// import Login from "../components/auth/Login";
import Login2 from "../components/auth/Login2";
// import Register from "../components/auth/Register";
import Register2 from "../components/auth/Register2";
import Dashboard from "../components/dashboard/Dashboard";
import Footer from "../components/layouts/Footer";
import Landing from "../components/layouts/Landing";
import Navbar from "../components/layouts/Navbar";
import CreateProfile from "../components/profile/CreateProfile";
import Profiles from "../components/profiles/Profiles";
import AddEducation from "../components/profile/AddEducation";
import AddExperience from "../components/profile/AddExperience";
import ViewProfile from "../components/displayProfile/ViewProfile";
import Posts from "../components/posts/Posts";
import Post from "../components/post/Post";

export const Routings = () => {
	const appName = "Zee 5";
	return (
		<div>
			<Router>
				<Navbar appName={appName} />
				<Routes>
					<Route path='/' element={<Landing />}></Route>
					<Route path='/login' element={<Login2 />}></Route>
					<Route path='/register' element={<Register2 />}></Route>
					<Route path='/dashboard' element={<Dashboard />}></Route>
					{/* <Route path='/create-profile' element={<CreateProfile />}></Route>
					<Route path='/edit-profile' element={<CreateProfile />}></Route>
					<Route path='/add-experience' element={<AddExperience />}></Route>
					<Route path='/add-education' element={<AddEducation />}></Route> */}
					<Route path='/profiles' element={<Profiles />}></Route>
					<Route path='/profile/:id' element={<ViewProfile />}></Route>
					<Route path='/posts' element={<Posts />}></Route>
					<Route path='/posts/:id' element={<Post />}></Route>
				</Routes>
				<Footer />
			</Router>
		</div>
	);
};
