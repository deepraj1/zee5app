import {
  CLEAR_PROFILE,
  GET_PROFILE,
  GET_PROFILES,
  GET_REPOS,
  NO_REPOS,
  PROFILE_ERROR,
  UPDATE_PROFILE,
} from "../types";

const initialState = {
  profile: null,
  profiles: [],
  repos: [],
  loading: true,
  error: {}
};

// eslint-disable-next-line import/no-anonymous-default-export
export default (state = initialState, action) => {

  const { type, payload } = action;

  switch (type) {
    case GET_PROFILE:
      return { ...state, profile: payload, loading: false };
    case GET_PROFILES:
      return { ...state, profiles: payload, loading: false };
    case GET_REPOS:
      return { ...state, repos: payload, loading: false };
    case NO_REPOS:
      return {
        ...state, repos: [], loading: false
      }
    case CLEAR_PROFILE:
      return {
        ...state,
        loading: false,
        profile: null,
        repos: []
      };
    case PROFILE_ERROR:
      return { ...state, error: payload, loading: false, profile: null };
    case UPDATE_PROFILE:
    default:
      return state;
  }
};
